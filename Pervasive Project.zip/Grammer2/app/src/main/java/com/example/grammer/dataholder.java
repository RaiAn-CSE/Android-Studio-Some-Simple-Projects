package com.example.grammer;

public class dataholder {
    String save;

    public dataholder(String save) {
        this.save = save;
    }

    public String getSave() {
        return save;
    }

    public void setSave(String save) {
        this.save = save;
    }
}
