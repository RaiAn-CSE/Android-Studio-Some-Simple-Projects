package com.example.grammer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Database extends AppCompatActivity {
    EditText editText1,editText2,editText3;
    TextView text1,text2,text3;
    Button Btn;
    DatabaseReference reff;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);

        editText1=findViewById(R.id.editTextId1);
        editText2=findViewById(R.id.editTextId2);
        editText3=findViewById(R.id.editTextId3);

        text1=findViewById(R.id.TextId1);
        text2=findViewById(R.id.TextId2);
        text3=findViewById(R.id.TextId3);

        Btn=findViewById(R.id.showBtnId);

        Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                reff = FirebaseDatabase.getInstance().getReference();
                reff.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        String I=dataSnapshot.child("id").getValue().toString();
                        String N=dataSnapshot.child("name").getValue().toString();
                        String D=dataSnapshot.child("dept").getValue().toString();

                        text1.setText(I);
                        text2.setText(N);
                        text3.setText(D);

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });
    }
    public void save(View view) {

        String id = editText1.getText().toString().trim();
        String name = editText2.getText().toString().trim();
        String dept = editText3.getText().toString().trim();

        dataholder1 obj = new dataholder1(id,name,dept);

        FirebaseDatabase db = FirebaseDatabase.getInstance();
        DatabaseReference node = db.getReference();

        node.setValue(obj);

        editText1.setText("");
        editText2.setText("");
        editText3.setText("");

        Toast.makeText(getApplicationContext(), "Value Inserted", Toast.LENGTH_SHORT).show();
    }
}