package com.example.bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText E1,E2;
    TextView resultText;
    String calculation,BMIresult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        E1=findViewById(R.id.editTextId1);
        E2=findViewById(R.id.editTextId2);
        resultText=findViewById(R.id.textViewId);
    }

    public void calculateFunction(View view) {
        String s1=E1.getText().toString();
        String s2=E2.getText().toString();

        float wv=Float.parseFloat(s1);
        float hv=Float.parseFloat(s2)/100;

        float bmi=wv/(hv*hv);

        calculation="Result:\n\n"+bmi;

        resultText.setText(calculation);
    }
}