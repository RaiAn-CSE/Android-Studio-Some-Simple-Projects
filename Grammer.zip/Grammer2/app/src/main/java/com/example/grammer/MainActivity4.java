package com.example.grammer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity4 extends AppCompatActivity {
    EditText editText;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        editText = findViewById(R.id.edittextId);
        button = findViewById(R.id.buttonNext);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity4.this,MainActivity5.class);
                startActivity(intent);
            }
        });
    }

    public void submitFunction(View view) {
        String save=editText.getText().toString().trim();
        dataholder obj=new dataholder(save);

        FirebaseDatabase db=FirebaseDatabase.getInstance();
        DatabaseReference node= db.getReference();
        node.setValue(obj);
        editText.setText("");

        Toast.makeText(getApplicationContext(),"Inserted",Toast.LENGTH_LONG).show();

    }
}