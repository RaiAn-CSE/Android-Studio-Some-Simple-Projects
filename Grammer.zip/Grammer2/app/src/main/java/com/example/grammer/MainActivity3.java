package com.example.grammer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity3 extends AppCompatActivity {
    RadioGroup radioGroup;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        radioGroup = findViewById(R.id.RadioGroupID);
        button = findViewById(R.id.buttonNext);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity3.this,MainActivity4.class);
                startActivity(intent);
            }
        });
    }

    public void submitFunction(View view) {
        if (radioGroup.getCheckedRadioButtonId() == R.id.radioBtn3) {

            Toast.makeText(this, "Right", Toast.LENGTH_LONG).show();

        } else {
            Toast.makeText(this, "Wrong", Toast.LENGTH_LONG).show();
        }
    }
}