package com.example.spinner;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    String[] name;
    TextView textView;
    Spinner spinner;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner=findViewById(R.id.spinnerid);
        btn=findViewById(R.id.btnid);
        textView=findViewById(R.id.textViewId);

        name=getResources().getStringArray(R.array.Country_name);

        ArrayAdapter adapter=new ArrayAdapter(this,R.layout.sample,R.id.spinnerTextid,name);
        spinner.setAdapter(adapter);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String value=spinner.getSelectedItem().toString();
                textView.setText(value);
                Toast.makeText(MainActivity.this, "Selected: "+value, Toast.LENGTH_SHORT).show();
            }
        });
    }
}